﻿using UnityEngine;
using System.Collections;

public class CharaParent : MonoBehaviour {
    public GameObject mCharaParent;
}
