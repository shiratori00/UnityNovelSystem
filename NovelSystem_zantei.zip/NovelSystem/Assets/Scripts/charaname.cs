﻿using UnityEngine;
using System.Collections;

public class charaname : MonoBehaviour {
    public GameObject mNameText;
}
