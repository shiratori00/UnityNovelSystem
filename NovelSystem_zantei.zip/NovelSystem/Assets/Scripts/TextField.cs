﻿using UnityEngine;
using System.Collections;

public class TextField : MonoBehaviour {

    public GameObject mTextField;

    void Start()
    {

    }

    void Update()
    {

    }
}
