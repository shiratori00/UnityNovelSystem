﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class JokerSetting : MonoBehaviour
{

		public Vector2 aspect = new Vector2(4,3);
		public Color32 backgroundColor = Color.black;

		void Start ()
		{

				//enabled = false;

		}



}